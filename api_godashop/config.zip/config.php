<?php
define('ABSPATH', __DIR__ . '/');
define('ABSPATH_SITE', ABSPATH . 'site/');
define('SERVERNAME', 'localhost');
define('USERNAME', 'root');
define('PASSWORD', '');
define('DBNAME', 'godashop_api_k99');

// SMTP (send mail)
define("SMTP_USERNAME", "nguyenthuchanh2021@gmail.com");
define("SMTP_SECRET", "howrfxnasqiuybxy");
define("SMTP_HOST", "smtp.gmail.com");
define("SHOP_OWNER", "nguyenhuulocla2006@gmail.com");

define("GOOGLE_RECAPTCHA_SITE", "6Lcj07oUAAAAALAHcj_WdDa7Vykqzui3mSA5SIoe");
define("GOOGLE_RECAPTCHA_SECRET", "6Lcj07oUAAAAAKKbrzK72AzMqqVwxnsVTjlvx_OJ");

define('JWT_KEY', 'godashop_k67');
// define("GOOGLE_CLIENT_ID", "467247032240-4k4stmd35nn0hhloqdvtg573qb6bo2pv.apps.googleusercontent.com");
// define("GOOGLE_CLIENT_SECRET", "EbrWc27MNlMK8fo30UZ2z13N");
define("GOOGLE_CLIENT_ID", "509012045176-9hsg97lflc78qo7psgaq0h9q18dj4o2e.apps.googleusercontent.com");
define("GOOGLE_CLIENT_SECRET", "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");

define("FACEBOOK_CLIENT_ID", "886552205696362");
define("FACEBOOK_CLIENT_SECRET", "1dc795423fea194a08bd469d4adc190d");

// define("FACEBOOK_CLIENT_ID", "1353188632098960");
// define("FACEBOOK_CLIENT_SECRET", "7865e2832e6469dd2b2a0da5189db3ac");